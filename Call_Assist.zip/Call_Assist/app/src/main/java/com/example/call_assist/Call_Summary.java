package com.example.call_assist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Call_Summary extends AppCompatActivity {

    AlertDialog.Builder builder;
    NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this);

    String alert_message = "";
    int start = 0;
    int end = 0;
    int index =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call__summary);

        builder = new AlertDialog.Builder(this);
        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        TextView textView = findViewById(R.id.textView1);

        String pat = "(([01]?[0-9]|2[0-3]):?[0-5]?[0-9]?( a.m.| p.m.)?).*";
        Pattern regX = Pattern.compile(pat);
        int i = 0, j = 0, k = 0;
        String words[] = message.split("\\s");
        int len = words.length;
        String n = "(\\d|\\s){10,20}";
        Pattern regNum = Pattern.compile(n);
        for (i = 0; i < len; i++) {

            if (words[i].equals("call")) {
                start = index;
                end = start + 4;
                StringBuffer subStr = new StringBuffer("");
                for (j = i + 1; j <= i + 10 && j < len; j++) {
                    subStr = subStr.append(" " + words[j]);
                }
                Matcher mat = regX.matcher(subStr);
                if (mat.find()) {
                    //Toast.makeText(getApplicationContext(), "Time:" + mat.group(0), Toast.LENGTH_LONG).show();
                    alert_message = "action: call,"+" time: " + mat.group(0);
                    //textView.setText("Time:" + mat.group(0));
                    System.out.println("Time:" + mat.group(0));

                }
            }
            if (words[i].equals("meet")) {
                String place = "";
                start = index;
                end = start + 4;
                StringBuffer subStr = new StringBuffer("");
                for (j = i + 1; j <= i + 10 && j < len - 1; j++) {
                    if (words[j].equals("in")) {
                        place += words[j + 1];
                        for (k = j + 1; k <= j + 10 && k < len; k++) {
                            subStr = subStr.append(" " + words[k]);
                        }
                    }
                }
                Matcher mat = regX.matcher(subStr);
                if (mat.find()) {
                    //textView.setText("Place:" + place + " time:" + mat.group(0));
                    //Toast.makeText(getApplicationContext(), "Place:" + place + " time:" + mat.group(0), Toast.LENGTH_LONG).show();
                    alert_message = "action: meet,"+" time: " + mat.group(0)+", place: "+place;
                    System.out.println("Place:" + place + " time:" + mat.group(0));

                }
            }
            if (words[i].equals("number")) {
                start = index;
                end = start + 6;
                StringBuffer subStr = new StringBuffer("");
                for (j = i + 1; j <= i + 20 && j < len; j++) {
                    subStr.append(" " + words[j]);
                }
                Matcher mat = regNum.matcher(subStr);
                if (mat.find()) {
                    //Toast.makeText(getApplicationContext(), "Number:" + mat.group(0), Toast.LENGTH_LONG).show();
                    alert_message = "action: save, "+ mat.group(0);
                    System.out.println("Number:" + mat.group(0));

                }
            }
            index+= words[i].length();

        }


        SpannableString ss = new SpannableString(message);
        ForegroundColorSpan fcsBlue = new ForegroundColorSpan(Color.BLUE);

        ss.setSpan(fcsBlue,start,end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Toast.makeText(getApplicationContext(), "Notification", Toast.LENGTH_LONG).show();
                builder.setMessage(alert_message)
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                finish();
                                Toast.makeText(getApplicationContext(),"you choose yes action to set reminder",
                                        Toast.LENGTH_SHORT).show();

//
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //  Action for 'NO' Button
                                dialog.cancel();
                                Toast.makeText(getApplicationContext(),"you choose no action for reminder",
                                        Toast.LENGTH_SHORT).show();
                            }
                        });
                //Creating dialog box
                AlertDialog alert = builder.create();
                //Setting the title manually
                alert.setTitle("Set Reminder");

                alert.show();
            }
            };
            ss.setSpan(clickableSpan,7,11,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(ss);
        textView.setMovementMethod(LinkMovementMethod.getInstance());
   }


//        textView.setText(ss);
//        textView.setText(message);
//        String textToHighlight = "the";
//
//        // Construct the formatted text
//        String replacedWith = "<font color='red'>" + textToHighlight + "</font>";
//
//        // Get the text from TextView
//        String originalString = mTextView.getText().toString();
//
//        // Replace the specified text/word with formatted text/word
//        String modifiedString = originalString.replaceAll(textToHighlight,replacedWith);
//
//        // Update the TextView text
//        mTextView.setText(Html.fromHtml(modifiedString));

    }


