package com.example.call_assist;

import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.widget.Toast;
import java.util.ArrayList;

import static android.Manifest.permission.RECORD_AUDIO;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class STT_Service extends Service {

    private SpeechRecognizer speech = null;
    private Intent recognizerIntent;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
//        return super.onStartCommand(intent, flags, startId);

        TelephonyManager manager = (TelephonyManager)getApplicationContext().getSystemService(getApplicationContext().TELEPHONY_SERVICE);
        manager.listen(new PhoneStateListener(){
            @Override
            public void onCallStateChanged(int state, String incomingNumber){
                //super.onCallStateChanged(state,incomingNumber){
                    if(TelephonyManager.CALL_STATE_IDLE==state && speech==null){

                        // stop speech to text
                        speech.stopListening();
                        stopSelf();
                    }else if(TelephonyManager.CALL_STATE_OFFHOOK==state){
                        start_STT();

                    }
                }

        },PhoneStateListener.LISTEN_CALL_STATE);
        return  START_STICKY;
    }

    private void start_STT() {

        speech = SpeechRecognizer.createSpeechRecognizer(this);
//        speech.setRecognitionListener(this);
        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.ACTION_VOICE_SEARCH_HANDS_FREE);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,
                "en");
        speech.startListening(recognizerIntent);


//        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
//        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.ACTION_VOICE_SEARCH_HANDS_FREE);
//
//        if(intent.resolveActivity(getPackageManager())!=null) {
//            startActivityForResult(intent, 10);
//        }
//        else{
//            Toast.makeText(getApplicationContext(), "this device doesn't support STT", Toast.LENGTH_LONG).show();
//        }
    }

//    @Override
//    protected void onActivityResult(int requestCode,int resultCode,Intent data){
//        super.onActivityResult(requestCode,resultCode,data);
//
//        switch(requestCode){
//            case 10:
//                if(resultCode== Activity.RESULT_OK && data!=null){
//                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
//                    Toast.makeText(getApplicationContext(), result.get(0), Toast.LENGTH_LONG).show();
//                }
//                break;
//        }
//    }
}
