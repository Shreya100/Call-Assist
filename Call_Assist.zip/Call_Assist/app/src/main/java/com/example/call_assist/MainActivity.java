package com.example.call_assist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    String text = "";
    BufferedReader reader=null;
    public static final String EXTRA_MESSAGE = "com.example.call_assist.MESSAGE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onCall(View view){
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:0377778888"));

            convert_to_text();
            if (ActivityCompat.checkSelfPermission(MainActivity.this,
    Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
        startActivity(callIntent);
        convert_to_text();
    }

    public void convert_to_text(){

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.ACTION_VOICE_SEARCH_HANDS_FREE);

        if(intent.resolveActivity(getPackageManager())!=null) {
            startActivityForResult(intent, 10);
        }
        else{
            Toast.makeText(getApplicationContext(), "this device doesn't support STT", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);

        switch(requestCode){
            case 10:
                if(resultCode== RESULT_OK && data!=null){
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                    //Toast.makeText(getApplicationContext(), result.get(0), Toast.LENGTH_LONG).show();

                    //sendDataToServer(result.get(0));

                    Intent intent = new Intent(this, Call_Summary.class);
                    intent.putExtra(EXTRA_MESSAGE, result.get(0));
                    startActivity(intent);
                }
                break;
        }
    }

    protected void sendDataToServer(String data){
        try
        {
            // Defined URL  where to send data
            URL url = new URL("http://127.0.0.1:8000/sendData");

            // Send POST data request
            URLConnection conn = url.openConnection();

            Toast.makeText(getApplicationContext(), data, Toast.LENGTH_LONG).show();
            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write( data );
            wr.flush();

            // Get the server response

            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;

            // Read Server Response
            while((line = reader.readLine()) != null)
            {
                // Append server response in string
                sb.append(line + "\n");
            }


            text = sb.toString();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            String err = String.valueOf(ex.getCause());
            System.out.println(err);
                Toast.makeText(getApplicationContext(), err, Toast.LENGTH_LONG).show();
        }
        finally
        {
            try
            {
                reader.close();
            }
            catch(Exception ex) {
            }
        }
    }

    protected void getDataFromServer(){
        try {
            URL url = new URL("http://127.0.0.1:8000/getData");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setDoOutput(true);
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.connect();
            BufferedReader rd = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String content = "", line;
            while ((line = rd.readLine()) != null) {
                content += line + "\n";
            }
            // data is in content
        }
        catch(Exception e){

        }
    }

}

