from django.apps import AppConfig


class ModelConfig(AppConfig):
    name = 'model'
