from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
from django.core.files.storage import FileSystemStorage
import pandas as pd
import numpy as np
import math
from django.core.files.storage import default_storage
import os
import csv
import re
from sklearn import preprocessing
from django.views.decorators.csrf import csrf_exempt
import nltk
import nltk
import spacy


notification = ""
sp = spacy.load('en_core_web_sm')


@csrf_exempt
def receiveData(request):
    try:
      if request.method == 'POST':
        print("Hello")
        data = request.POST.get("data")
        print(data)
        process_data(data)
        return HttpResponse("Success")
    except:
      return HttpResponse('Error:500')

def sendData(request):
    if request.method == "GET":
        return HttpResponse(notification)

def makeMessage(sentance):
    global notification 
    sen = sp(sentance)
    print("coming to message")
    for i,word in enumerate(sen):
        if(word.pos_ == "VERB"):
            notification = notification + str(word)+" " 
        if(word.pos_ == "NOUN"):
            notification = notification + str(word)+" "  
        if(word.pos_ == "NUM"):
            notification = notification + str(word)+" "  
    print(notification)
            

def process_data(data):
    data = "Hey,my name is Shreya.What's up? can we meet  at Indranagar at 6pm today"

    sentances = nltk.sent_tokenize(data)

    action_sentance = ""

    for sentance in sentances:
        sen = sp(sentance)
        pos_tags = []
        for word in sen:
            pos_tags.append(word.pos_)
        #print(f'{word.text:{12}} {word.pos_:{10}} {word.tag_:{8}} {spacy.explain(word.tag_)}')
        print(pos_tags)
        flag = 0
        if(all(x in pos_tags for x in ['VERB','ADP','NOUN','NUM'])): 
            flag = 1
        if flag==1:
            action_sentance = sentance
            makeMessage(action_sentance)
